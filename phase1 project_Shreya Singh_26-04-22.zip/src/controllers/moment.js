const moment = require("moment")


let date = moment().format('DD/MMM/YY');
console.log(date)