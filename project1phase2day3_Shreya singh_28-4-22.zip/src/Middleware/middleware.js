const jwt = require("jsonwebtoken");
// let a = req.headers["x-api-key"]

const authenticate = function (req, res, next) {

    //check the token in request header
    //validate this token
    let a = req.headers["x-api-key"]
    if (!a) { a = req.headers["x-Api-key"] }
    if (!a) return res.send('you have need a token')
    let c = req.headers["x-api-key"]
    let b = jwt.verify(c, "project1-group3")
    if (!b) return res.send('invalid token')
    console.log(c)


    next()
}


const authorise = function (req, res, next) {
    try {
        // comapre the logged in user's id and the id in request
        let token = req.headers["x-api-key"];
        let decodedToken = jwt.verify(token, "project1-group3");
        if (!decodedToken)
            return res.send({ status: false, msg: "token is invalid" });
        
        let userId = req.params.userId;
        let userLogged = decodedToken.userId
        if(userId != userLogged){
            return res.send({ status : false, msg: "you are not authorised to change data"})
        }
        // let verify = decodedToken.userId == userId
        // if (!verify) return res.send({ msg: 'not a vaid user' })
    }
    catch (err) {
        console.log(err)
        res.status(500).send({ msg: "error", err: err.message })
    }  next()
}

module.exports.authenticate = authenticate
module.exports.authorise = authorise
