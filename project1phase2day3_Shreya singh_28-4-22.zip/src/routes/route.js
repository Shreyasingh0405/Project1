const express = require('express');
const router = express.Router();


const authorController= require("../controllers/authorController")
const blogController= require("../controllers/blogController")
const middleware = require("../Middleware/middleware.js")
const userController= require("../controllers/userController")


router.post("/author",authorController.createAuthor)

router.post("/blogs",blogController.createBlogger)

router.get("/getBlogsData",blogController.getBlogsData)

router.get("/getblog",blogController.getblog)

router.put("/updateData/:blogId",blogController.upData)

router.put("/status/:userId",blogController.status)

router.delete("/blogs/:blogId",blogController.deleteblog)

router.delete("/lastDelete",blogController.deleteByElement )

router.post("/login", userController.loginUser)

//The userId is sent by front end
router.get("/blogs/:blogId",middleware.authenticate, blogController.getBlogsData)
//router.post("/users/:userId/", blogController.upData)

 router.put("/blogs/:blogId",middleware.authorise,middleware.authenticate, blogController.upData)
router.delete('/blogs/:blogId',middleware.authorise,middleware.authenticate, blogController.deleteblog)











module.exports = router;
