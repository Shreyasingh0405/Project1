const moment = require("moment")


let date = moment().format('DD/MMM/YY, h:mm:ss a');
console.log(date)